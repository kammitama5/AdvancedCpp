#include "Time.h"
#include <iostream>
#include <string>

#include "Date.h"
#include "CourseSchedule.h"
#include "Course.h"

//CourseSchedule::CourseSchedule(std::string, Semester, int){

//}

CourseSchedule::~CourseSchedule(){

}

std::string CourseSchedule::getStudentName(){
	return "ha";
}

std::string CourseSchedule::getSemester(){
	return "ha";
}
std::string CourseSchedule::getNumCourses(){
	return "ha";
}

void setStudentName(){

}

//make sure course dates are not outside semester date in this function
/*
void CourseSchedule::checkDates(Semester(semester()), CourseDates coursedates, ){

}
*/

void addCourse(Course()){

} // prints out confirming that has been added to
// course schedule array

//remove course
//update numCourses
void removeCourse(Course){

}
