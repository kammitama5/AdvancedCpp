#include "Date.h"
#include <iostream>
#include <string>




Date::Date(int, int, int){


}

void Date::setDate(int, int, int){

}

void Date::setHour(int){

}

void Date::setDay(int){

}

void Date::setYear(int){

}

int Date::getMonth() const{
	return 0;
}
int Date::getDay() const{

	return 0;
}

int Date::getYear() const{

	return 0;
}